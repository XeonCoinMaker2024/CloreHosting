const docker_interface = require('./lib/docker-interface')
const clore_interface = require('./lib/clore-interface')
const image_managment = require('./lib/image-managment')
const get_specs = require('./lib/get-specs')
const os=require('os')
const docker_prefix = "clore"
const fs=require('fs')
const utils = require('./lib/utils')

const local_ip_ranges=["10.0.0.0/8","100.64.0.0/10","172.16.0.0/15","172.19.0.0/16","172.20.0.0/14","172.24.0.0/14","172.28.0.0/14","192.168.0.0/16"]

var init_token='',it_param=false,reset=false,main=false

for(var i=0;i<process.argv.length;i++){
    let c_arg=process.argv[i]
    if(c_arg==`--init-token`){
        if(process.argv[i+1]) init_token=process.argv[i+1]
        it_param=true
    }else if(c_arg==`--reset`){
        reset=true
    }else if(c_arg=="-main" && process.argv[i+1]=="true"){
        main=true
    }
}

if(it_param || reset){
    try{
        let exists=fs.existsSync(`./auth`)
        if(reset && exists){
            console.log(`\x1b[31mDo you really want to reset client?\x1b[0m\nIf you reset, authorization key will be dumped and you will never be able to login as the old server\n(Y/n)`)
            var stdin = process.stdin;
            stdin.setRawMode( true );
            stdin.resume();
            stdin.setEncoding( 'utf8' );
            stdin.on( 'data', function( key ){
              if(key.toLowerCase()=='n'){
                process.exit(0)
              }else if(key.toLowerCase()=='y'){
                fs.unlinkSync(`./auth`)
                console.log(`\x1b[32mClient login reseted\x1b[0m`)
                process.exit(0)
              }
              process.stdout.write(key);
            });
        }else if(reset){
            console.log(`\x1b[31mCan't reset not logged in client\x1b[0m`)
            process.exit(0)
        }else if(exists && it_param){
            console.log(`\x1b[31mServer has already set up login credentials\x1b[0m`)
        }else if(it_param && init_token){
            if(init_token.length!=48){
                console.log(`\x1b[31mInvalid token\x1b[0m`)
                process.exit(1)
            }else{
                init(init_token)
            }
        }else if(it_param){
            console.log(`\x1b[31mNo token supplied\x1b[0m`)
            process.exit(1)
        }
    }catch(e){
        console.log(e)
        console.log(`\x1b[31mDisk reading issue`,`\x1b[0m`)
    }
}else if(!main){
    console.log(`Clore client help\n--init-token <token> (Initialize server)\n--reset (Remove current login)`)
    process.exit(0)
}else{
    fs.readFile('./auth', {encoding:'utf8', flag:'r'}, function(err, data) {
        if(err){
            console.log((err.code=="ENOENT")?
            `\x1b[31mCLORE.AI client not initialized yet\nsee --help for more info`:
            `\x1b[31mDisk reading issue`,`\x1b[0m`)
            process.exit(1)
        }else{ // validate network config
            (async () => {
                let iptables_res = await docker_interface.sync_exec(`iptables -S`), ip_a = await docker_interface.sync_exec(`ip --json a`)
                if(iptables_res["code"]==0 && !iptables_res["stderr"] && ip_a["code"]==0 && !ip_a["stderr"]){
                    let parsed_json
                    try{
                        parsed_json=JSON.parse(ip_a["stdout"])
                    }catch(e){console.error(e)}
                    if(parsed_json){
                        let interfaces = parsed_json,found_interface=false
                        for(var i=0;i<interfaces.length;i++){
                            let c_interface_name=interfaces[i]["ifname"],iti=false
                            if(c_interface_name.substring(0,3)=="br-"){
                                let c_net=interfaces[i]["addr_info"]
                                for(var x=0;x<c_net.length;x++){
                                    let c_s=c_net[x]
                                    if(`${c_s["local"]}/${c_s["prefixlen"]}`=="172.18.0.1/16") iti=true
                                }
                            }
                            if(iti){
                                found_interface=true
                                for(var x=0;x<local_ip_ranges.length;x++){
                                    let c_ip_range=local_ip_ranges[x]
                                    if(!iptables_res["stdout"].includes(`-A FORWARD -d ${c_ip_range} -i ${c_interface_name} -j DROP`)){
                                        let command = `iptables -I FORWARD -i ${c_interface_name} -d ${c_ip_range} -j DROP`
                                        let set_res = await docker_interface.sync_exec(command)
                                        if(set_res["code"]!=0){
                                            console.log(`\x1b[31mIPTABLES writing issue`,`\x1b[0m`)
                                            process.exit(1)
                                        }
                                    }
                                }
                            }
                        }
                        if(found_interface){
                            clore_interface.init(data.toString())
                            docker_interface.handle_startup_scripts(docker_prefix)
                            run()
                            do_image_mgmt()
                        }else{
                            console.log(`\x1b[31mbridge interface don't exist`,`\x1b[0m`)
                            process.exit(1)
                        }
                    }else{
                        console.log(`\x1b[31mNETWORK CONFIGURATION reading issue`,`\x1b[0m`)
                        process.exit(1)
                    }
                }else{
                    console.log(`\x1b[31mIPTABLES reading issue`,`\x1b[0m`)
                    process.exit(1)
                }
            })();
        }
    });
}

async function init(init_token){
    const P = ['\\', '|', '/', '-'];
    let xx = 0;
    const loader = setInterval(() => {
      process.stdout.write(`\r${P[xx++]} Getting server specifications`);
      xx %= P.length;
    }, 100);
    let cerr=''
    let specs = await get_specs.get_complete_specs().catch(function (err) {cerr=err})
    clearInterval(loader);
    if(cerr){
        console.log(`\rGetting server specifications - [ \x1b[31mERROR\x1b[0m `);
        console.log(`\x1b[31m${cerr}\x1b[0m`)
        process.exit(1)
    }else{
        let u = console.log(`\rGetting server specifications - [ \x1b[32mCOMPLETE \x1b[0m]`);
        let max_str_l=64
        for(var i=0;i<Object.keys(specs).length;i++){
            let ckey=Object.keys(specs)[i]
            if(ckey=="net"){

            }else if(ckey=="disk" && specs[ckey].toString().length>max_str_l){
                let p=specs[ckey].split(' '),ft=''
                let req_size=p[p.length-1]
                for(var x=0;x<(p.length-1);x++){
                    ft+=`${p[x]} `
                }
                ft=ft.substring(0,(max_str_l-req_size.length-1))
                if(ft[ft.length-3]==' '){
                    specs[ckey]=`${ft} ${req_size}`
                }else{
                    specs[ckey]=`${ft} ${req_size}`
                }
            }else if(specs[ckey].toString().length>max_str_l) {
                specs[ckey] = specs[ckey].toString().substring(0,max_str_l)
            }
        }
        //console.log(specs)
        cerr=''
        let pct=utils.generate_random_string(32)
        await clore_interface.register_server(init_token,pct,specs).catch(function (err) {cerr=err})
        if(cerr=="fail"){
            console.log(`\x1b[31mIssues connecting to CLORE.AI api, check your internet connection or try it later\x1b[0m`)
        }else if(cerr=="invalid_key"){
            console.log(`\x1b[31mInvalid token\x1b[0m`)
        }else if(cerr=="clore_error"){
            console.log(`\x1b[31mIssues at CLORE.AI, please try again later\x1b[0m`)
        }else if(cerr=="already_updated"){
            console.log(`\x1b[31mThis token is already used by some server\x1b[0m`)
        }else{
            try{
                fs.appendFileSync(`./auth`,`${init_token}:${pct}`)
                console.log(`\x1b[32mServer successfully logged in\x1b[0m`)
                process.exit(0)
            }catch(e){
                console.log(`\x1b[31mIssue saving verified login on machine\x1b[0m`)
            }
        }
        process.exit(1)
    }
}

async function run(){
    try{
        let c = clore_interface.get_containers(),cerr=''
        if(c!="not-received-yet") await docker_interface.set_containers(c,docker_prefix).catch(function (err) {cerr=err})
    }catch(e){}
    setTimeout(function(){
        run()
    },200)
}
async function do_image_mgmt(){
    try{
        await image_managment.compare().catch(function (err) {console.error(err)})
    }catch(e){}
    setTimeout(function(){
        do_image_mgmt()
    },1000)
}